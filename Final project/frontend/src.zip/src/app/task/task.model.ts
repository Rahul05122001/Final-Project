export interface Task {
    id ?: number;
    taskdescription:string;
    completed:boolean;
}
