package com.todo.todoapplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TodoapplicationApplication {

	public static void main(String[] args) {
		SpringApplication.run(TodoapplicationApplication.class, args);
	}

}
